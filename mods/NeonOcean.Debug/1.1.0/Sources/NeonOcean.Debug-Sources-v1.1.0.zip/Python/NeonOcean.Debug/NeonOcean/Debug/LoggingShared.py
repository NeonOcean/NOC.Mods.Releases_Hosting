import enum

class LoggingModes(enum.Int):
	Burst = 0  # type: LoggingModes
	Continuous = 1  # type: LoggingModes
