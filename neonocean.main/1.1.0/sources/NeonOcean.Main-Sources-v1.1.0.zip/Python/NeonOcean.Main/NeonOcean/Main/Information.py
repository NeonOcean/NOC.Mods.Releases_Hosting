Author = "NeonOcean"  # type: str
GlobalNamespace = "NeonOcean.Global"  # type: str