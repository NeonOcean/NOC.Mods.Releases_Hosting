NeonOceanID = 4719607191068539616  # type: int

MainID = 12549383167398389681  # type: int
MainModSettingsID = 8358652581026300546  # type: int
