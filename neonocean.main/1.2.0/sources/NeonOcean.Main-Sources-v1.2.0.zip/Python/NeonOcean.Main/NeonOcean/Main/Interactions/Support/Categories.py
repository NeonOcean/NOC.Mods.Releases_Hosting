NeonOceanID = 4719607191068539616  # type: int

DebugID = 9828540712044566059  # type: int
DebugModSettingsID = 7714482771736482519  # type: int

MainID = 12549383167398389681  # type: int
MainModSettingsID = 8358652581026300546  # type: int

OrderID = 10635246917734688906  # type: int
OrderModSettingsID = 16847123929679880475  # type: int
