DebugID = 9828540712044566059  # type: int
DebugModSettingsID = 7714482771736482519  # type: int