### Debugger Support (Status: Idea)
- Would allow The Sims 4's python to connect to popular python debuggers.

### Create Stubs From Built-In Python Modules (Status: Idea)
- Could automatically read the structure of The Sims 4's built-in Python modules and output it as a stub module file.