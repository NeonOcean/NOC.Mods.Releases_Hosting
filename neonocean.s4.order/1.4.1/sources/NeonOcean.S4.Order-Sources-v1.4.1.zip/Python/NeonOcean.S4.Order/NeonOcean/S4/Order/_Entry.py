from __future__ import annotations

from NeonOcean.S4.Order import Loading

Loading.LoadAll()
