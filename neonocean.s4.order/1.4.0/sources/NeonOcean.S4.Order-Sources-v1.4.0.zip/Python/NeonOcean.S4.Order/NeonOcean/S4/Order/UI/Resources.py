# noinspection SpellCheckingInspection
PickerRightArrowIconKey = "00B2D882:00000000:38D63245CC037C1F"  # type: str

# noinspection SpellCheckingInspection
PickerGearIconKey = "00B2D882:00000000:188D7F9F936DEAA6"  # type: str

# noinspection SpellCheckingInspection
PickerLockIconKey = "00B2D882:00000000:144FA1139F00C553"  # type: str

# noinspection SpellCheckingInspection
PickerResetIconKey = "00B2D882:00000000:4B1A7F7632C7823F"  # type: str
