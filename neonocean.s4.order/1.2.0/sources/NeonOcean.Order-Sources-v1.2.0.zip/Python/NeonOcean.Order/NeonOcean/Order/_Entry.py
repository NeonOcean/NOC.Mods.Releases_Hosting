from NeonOcean.Order import Loading

Loading.Load()
