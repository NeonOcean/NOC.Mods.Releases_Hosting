Author = "NeonOcean"  # type: str
RootNamespace = "NeonOcean"  # type: str
GlobalNamespace = "NeonOcean.Global"  # type: str
