# noinspection SpellCheckingInspection
PickerRightArrowIconKey = "00B2D882:00000000:C80E2017AD6B7837"  # type: str

# noinspection SpellCheckingInspection
PickerCheckIconKey = "00B2D882:00000000:0FA8C787442F010D"  # type: str

# noinspection SpellCheckingInspection
PickerBlankIconKey = "00B2D882:00000000:A916F260EE7D97D9"  # type: str

# noinspection SpellCheckingInspection
PickerPlusIconKey = "00B2D882:00000000:E6591AC23DE19ECB"  # type: str

# noinspection SpellCheckingInspection
PickerPencilIconKey = "00B2D882:00000000:D2991A748FE06B6F"  # type: str

# noinspection SpellCheckingInspection
PickerTextIconKey = "00B2D882:00000000:D61D41E16C106518"  # type: str

# noinspection SpellCheckingInspection
PickerTrashCanIconKey = "00B2D882:00000000:4C29E22FEAD75E86"  # type: str