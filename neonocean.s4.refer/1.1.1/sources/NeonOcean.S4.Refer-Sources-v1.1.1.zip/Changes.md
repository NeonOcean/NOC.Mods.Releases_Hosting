## v1.1.1 (December 15, 2020)

- Fixed bug where an exception occurs because text with one or more non-sim token appears.

______________________________

## v1.1.0 (December 12, 2020)

- Added support for Main's new bug reporting feature.
- Fixed minor issues with new Star Wars and Snowy Escape packs.

______________________________

## v1.1.0-alpha.2 (November 1, 2020)

## Custom Pronoun Set Creator
- Added a way to delete custom pronoun sets.
- Various other improvements

______________________________

## v1.1.0-alpha.1 (September 21, 2020)

## Custom Pronoun Set Creator
- Added a way to create custom pronoun sets.

______________________________

## v1.0.1 (September 1, 2020)
 - Fixed an issue that can occur when another mod uses the gender tag in a weird way I've never seen before.

______________________________

## v1.0.0 (August 19, 2020)
 - Initial release