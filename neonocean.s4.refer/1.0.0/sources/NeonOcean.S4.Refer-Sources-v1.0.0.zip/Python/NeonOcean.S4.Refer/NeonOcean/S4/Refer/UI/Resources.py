# noinspection SpellCheckingInspection
PickerCheckIconKey = "00B2D882:00000000:E854FA926119B51C"  # type: str

# noinspection SpellCheckingInspection
PickerBlankIconKey = "00B2D882:00000000:A916F260EE7D97D9"  # type: str