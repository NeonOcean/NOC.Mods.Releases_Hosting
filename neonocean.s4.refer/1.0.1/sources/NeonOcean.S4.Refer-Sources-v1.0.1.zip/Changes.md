## v1.0.1 (September 1, 2020)
 - Fixed an issue that can occur when another mod uses the gender tag in a weird way I've never seen before.

## v1.0.0 (August 19, 2020)
 - Initial release