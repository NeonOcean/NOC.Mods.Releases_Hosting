These are the sources for the mod NeonOcean.S4.Main.  
Do not install the mod sources into your game as it will not function in this form.  
All repositories should be up to date with the current public versions of the mod.  
Please refer to the license file located in this directory for legal information about this mod.  


You can find more information about this mod at:  
https://www.neonoceancreations.com/mods/s4/main

You can find more of my mods here.  
https://www.neonoceancreations.com

You can support my work through my Patreon.  
https://www.patreon.com/NeonOcean
