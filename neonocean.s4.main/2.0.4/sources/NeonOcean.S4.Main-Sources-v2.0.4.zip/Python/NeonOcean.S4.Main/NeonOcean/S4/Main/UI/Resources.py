# noinspection SpellCheckingInspection
Transparent128IconKey = "00B2D882:00000000:A4DB6EBAE174821B"  # type: str

# noinspection SpellCheckingInspection
PickerRightArrowIconKey = "00B2D882:00000000:D7FD30B17013DA00"  # type: str

# noinspection SpellCheckingInspection
PickerGearIconKey = "00B2D882:00000000:516C6ECD2D27706E"  # type: str

# noinspection SpellCheckingInspection
PickerLockIconKey = "00B2D882:00000000:534956E4FA5D69B3"  # type: str

# noinspection SpellCheckingInspection
PickerResetIconKey = "00B2D882:00000000:788AF902B3C388ED"  # type: str

# noinspection SpellCheckingInspection
PickerCheckIconKey = "00B2D882:00000000:F24D9C5F3292807E"  # type: str

# noinspection SpellCheckingInspection
PickerBlankIconKey = "00B2D882:00000000:545D3611D9F9CBFB"  # type: str

# noinspection SpellCheckingInspection
PickerDownloadIconKey = "00B2D882:00000000:60C188DE40A033AF"  # type: str