Author = "NeonOcean"  # type: str
RootNamespace = "NeonOcean"  # type: str
RootNamespaceShortened = "NO"  # type: str
GameNamespace = "NeonOcean.S4"  # type: str
GlobalNamespace = "NeonOcean.S4.Global"  # type: str
