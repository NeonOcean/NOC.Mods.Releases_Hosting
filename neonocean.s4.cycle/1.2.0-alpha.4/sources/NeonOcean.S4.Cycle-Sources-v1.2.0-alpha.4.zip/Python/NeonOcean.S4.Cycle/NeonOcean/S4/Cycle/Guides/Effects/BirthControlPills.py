from __future__ import annotations

import typing

import snippets
from NeonOcean.S4.Cycle import This
from NeonOcean.S4.Cycle.Guides import Base as GuidesBase
from NeonOcean.S4.Main.Tools import Exceptions
from sims4.tuning import tunable

# noinspection PyTypeChecker
DefaultBirthControlPillsEffectGuide = None  # type: BirthControlPillsEffectGuide
BirthControlPillsEffectGuideIdentifier = "BirthControlPillsEffect"  # type: str

class BirthControlPillsEffectGuide(tunable.HasTunableSingletonFactory, tunable.AutoFactoryInit, GuidesBase.GuideBase):
	FACTORY_TUNABLES = {
		"NeedRateOfChange": tunable.Tunable(description = "The rate of change per reproductive minute of the birth control pills effect's need value. (The need value goes from 0 to 1, with 1 being the most need).", tunable_type = float, default = 0.00046296296)
	}

	NeedRateOfChange: float

	@classmethod
	def GetIdentifier (cls):
		"""
		Get an identifier that can be used to pick out a specific guide from a group.
		"""

		return BirthControlPillsEffectGuideIdentifier

	@classmethod
	def GetDefaultGuide (cls):
		"""
		Get a default instance of this guide.
		"""

		return DefaultBirthControlPillsEffectGuide

	@classmethod
	def GetGuide (cls, guideGroup):
		"""
		Get this guide group's instance of this guide or the default guide, if the group doesn't have a copy.
		"""

		from NeonOcean.S4.Cycle.GuideGroups import Base as GuidesGroupsBase

		if not isinstance(guideGroup, GuidesGroupsBase.GuideGroup):
			raise Exceptions.IncorrectTypeException(guideGroup, "guideGroup", (GuidesGroupsBase.GuideGroup,))

		guideGroupGuide = guideGroup.GetGuide(cls.GetIdentifier())  # type: typing.Optional[GuidesBase.GuideBase]
		return guideGroupGuide if guideGroupGuide is not None else cls.GetDefaultGuide()

class HumanBirthControlPillsEffectGuide(GuidesBase.GuideTuningHandler):
	_snippetName = This.Mod.Namespace.replace(".", "_") + "_Human_Birth_Control_Pills_Effect_Guide"

	Guide = None  # type: BirthControlPillsEffectGuide

	@classmethod
	def _GetSnippetTemplate (cls) -> tunable.TunableBase:
		return BirthControlPillsEffectGuide.TunableFactory()

	@classmethod
	def _SnippetTuningCallback (cls, guideSnippets: typing.List[snippets.SnippetInstanceMetaclass]) -> None:
		from NeonOcean.S4.Cycle import GuideGroups

		global DefaultBirthControlPillsEffectGuide

		super()._SnippetTuningCallback(guideSnippets)
		GuideGroups.HumanGuideGroup.Guides.append(HumanBirthControlPillsEffectGuide.Guide)

		DefaultBirthControlPillsEffectGuide = cls.Guide

def _Setup () -> None:
	global DefaultBirthControlPillsEffectGuide

	DefaultBirthControlPillsEffectGuide = BirthControlPillsEffectGuide.TunableFactory().default

_Setup()
