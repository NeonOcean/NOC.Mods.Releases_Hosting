from __future__ import annotations

import typing

from NeonOcean.S4.Cycle import Events as CycleEvents, Guides as CycleGuides, ReproductionShared
from NeonOcean.S4.Cycle.Effects import Base as EffectsBase, Shared as EffectsShared, Menstrual as EffectsMenstrual
from NeonOcean.S4.Cycle.Universal import EffectTracker, Shared as UniversalShared
from NeonOcean.S4.Main.Tools import Classes, Exceptions, Savable

class BirthControlPills(EffectsBase.EffectBase):
	def __init__ (self, effectingSystem: ReproductionShared.ReproductiveSystem):
		super().__init__(effectingSystem)

		self.Need = 0
		self.Entrenchment = 0

		self.RegisterSavableAttribute(Savable.StandardAttributeHandler("Need", "Need", self.Need))
		self.RegisterSavableAttribute(Savable.StandardAttributeHandler("Entrenchment", "Entrenchment", self.Entrenchment))

	# noinspection PyMethodParameters
	@Classes.ClassProperty
	def TypeIdentifier (cls) -> str:
		"""
		This effect type's identifier, this is used to save and load the effect. Loading will not be possible unless the cycle type is registered
		through the function in the effect types module.
		"""

		return EffectsShared.BirthControlPillsEffectTypeIdentifier

	@property
	def BirthControlPillsEffectGuide (self) -> CycleGuides.BirthControlPillsEffectGuide:
		"""
		Get the menstruation effect guide for this affecting sim.
		"""

		return CycleGuides.BirthControlPillsEffectGuide.GetGuide(self.AffectingSystem.GuideGroup)

	@property
	def Need (self) -> float:
		"""
		A measure of how recently the affecting system last took a birth control pill, from 0 to 1. At a value of 0, the sim has just taken a new pill. With a
		value of 1, the sim has not taken their medicine around the time they where suppose to and the entrenchment value should be decreasing.
		"""

		return self._need

	@Need.setter
	def Need (self, value: float) -> None:
		if not isinstance(value, (float, int)):
			raise Exceptions.IncorrectTypeException(value, "Need", (float, int))

		if value < 0 or value > 1:
			raise ValueError("Need values must be between 0 and 1.")

		self._need = value

	@property
	def Entrenchment (self) -> float:
		"""
		A number from 0 to 1 indicating how entrenched the medication is. This is used to simulate how birth control might not stop the first ovulation after you start
		taking them, or how periods will eventually become lighter or stop. It also is used to simulate how it may take a few weeks to start ovulating again after you
		stop taking the pills
		"""

		return self._entrenchment

	@Entrenchment.setter
	def Entrenchment (self, value: float) -> None:
		if not isinstance(value, (float, int)):
			raise Exceptions.IncorrectTypeException(value, "Entrenchment", (float, int))

		if value < 0 or value > 1:
			raise ValueError("Entrenchment values must be between 0 and 1.")

		self._entrenchment = value

	def _SetTrackerCallbacks (self, tracker) -> None:
		if tracker.TypeIdentifier == UniversalShared.EffectTrackerIdentifier:
			self._SetEffectTrackerCallbacks(tracker)

	def _SetEffectTrackerCallbacks (self, tracker) -> None:
		for effect in tracker.ActiveEffects:
			self._SetEffectCallbacks(effect)

		tracker.EffectAddedEvent += self._EffectsTrackerEffectAddedCallback
		tracker.EffectRemovedEvent += self._EffectsTrackerEffectRemovedCallback

	def _UnsetTrackerCallbacks (self, tracker) -> None:
		if tracker.TypeIdentifier == UniversalShared.EffectTrackerIdentifier:
			self._UnsetEffectTrackerCallbacks(tracker)

	def _UnsetEffectTrackerCallbacks (self, tracker) -> None:
		for effect in tracker.ActiveEffects:
			self._UnsetTrackerCallbacks(effect)

		tracker.EffectAddedEvent -= self._EffectsTrackerEffectAddedCallback
		tracker.EffectRemovedEvent -= self._EffectsTrackerEffectRemovedCallback

	def _SetEffectCallbacks (self, effect) -> None:
		if effect.TypeIdentifier == EffectsShared.MenstrualEffectTypeIdentifier:
			self._SetMenstrualEffectCallbacks(effect)

	def _SetMenstrualEffectCallbacks (self, effect) -> None:
		effect.BuffSelectionTestingEvent += self._MenstrualEffectBuffSelectionTestingCallback

	def _UnsetEffectCallbacks (self, effect) -> None:
		if effect.TypeIdentifier == EffectsShared.MenstrualEffectTypeIdentifier:
			self._UnsetMenstrualEffectCallbacks(effect)

	def _UnsetMenstrualEffectCallbacks (self, effect) -> None:
		effect.BuffSelectionTestingEvent -= self._MenstrualEffectBuffSelectionTestingCallback

	def _OnAdded (self) -> None:
		self.AffectingSystem.TrackerAddedEvent += self._TrackerAddedCallback

		for tracker in self.AffectingSystem.Trackers:  # type: ReproductionShared.TrackerBase
			self._SetTrackerCallbacks(tracker)

	def _OnRemoving (self) -> None:
		self.AffectingSystem.TrackerAddedEvent -= self._TrackerAddedCallback

		for tracker in self.AffectingSystem.Trackers:  # type: ReproductionShared.TrackerBase
			self._UnsetTrackerCallbacks(tracker)

	def _SimulateInternal (self, simulation: ReproductionShared.Simulation, ticks: int, reproductiveTimeMultiplier: float) -> None:
		simulatingMinutes = ReproductionShared.TicksToReproductiveMinutes(ticks, reproductiveTimeMultiplier)  # type: float

		effectGuide = self.BirthControlPillsEffectGuide  # type: CycleGuides.BirthControlPillsEffectGuide

		if effectGuide.NeedRateOfChange != 0:
			if effectGuide.NeedRateOfChange > 0:
				if self.Need != 1:
					self.Need += min(max(simulatingMinutes * effectGuide.NeedRateOfChange, 0), 1)
			else:
				if self.Need != 0:
					self.Need += min(max(simulatingMinutes * effectGuide.NeedRateOfChange, 0), 1)

	# noinspection PyUnusedLocal
	def _TrackerAddedCallback (self, owner: ReproductionShared.ReproductiveSystem, eventArguments: CycleEvents.TrackerAddedArguments) -> None:
		self._SetTrackerCallbacks(eventArguments.Tracker)

	# noinspection PyUnusedLocal
	def _TrackerRemovedCallback (self, owner: ReproductionShared.ReproductiveSystem, eventArguments: CycleEvents.TrackerAddedArguments) -> None:
		self._UnsetTrackerCallbacks(eventArguments.Tracker)

	# noinspection PyUnusedLocal
	def _EffectsTrackerEffectAddedCallback (self, owner: EffectTracker.EffectTracker, eventArguments: CycleEvents.EffectAddedArguments) -> None:
		self._SetEffectCallbacks(eventArguments.AddedEffect)

	# noinspection PyUnusedLocal
	def _EffectsTrackerEffectRemovedCallback (self, owner: EffectTracker.EffectTracker, eventArguments: CycleEvents.EffectRemovedArguments) -> None:
		self._UnsetEffectCallbacks(eventArguments.RemovedEffect)

	def _MenstrualEffectBuffSelectionTestingCallback (self, owner: EffectsMenstrual.MenstrualEffect, eventArguments: CycleEvents.MenstrualEffectBuffSelectionTestingArguments) -> None:
		pass



