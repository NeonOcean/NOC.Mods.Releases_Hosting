from __future__ import annotations

MenstrualEffectTypeIdentifier = "Menstrual"  # type: str
