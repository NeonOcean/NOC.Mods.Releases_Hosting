from __future__ import annotations

import typing

from NeonOcean.S4.Cycle import This
from NeonOcean.S4.Main import Debug
from NeonOcean.S4.Main.Interactions.Support import Dependent, Events, Registration
from interactions.base import immediate_interaction
from event_testing import test_base, results

SimSettingsInteractions = list()  # type: typing.List[typing.Type[SimSettingsInteraction]]

class SimSettingsInteraction(Dependent.DependentExtension, Events.EventsExtension, Registration.RegistrationExtension, immediate_interaction.ImmediateSuperInteraction):
	DependentMod = This.Mod

	class DisabledInteractionTest(test_base.BaseTest):
		# noinspection SpellCheckingInspection
		def __call__ (self):
			return results.TestResult(False)

		def get_expected_args (self) -> dict:
			# noinspection SpellCheckingInspection
			return dict()

	def __init_subclass__ (cls, *args, **kwargs):
		try:
			super().__init_subclass__(*args, **kwargs)

			SimSettingsInteractions.append(cls)
			cls.add_additional_test(cls.DisabledInteractionTest())
		except Exception as e:
			Debug.Log("Failed to initialize new sub class for '" + cls.__name__ + "'.", This.Mod.Namespace, Debug.LogLevels.Exception, group = This.Mod.Namespace, owner = __name__)
			raise e
