## v1.2.0-alpha.1 (2020)

### Pregnancy Test
- Added new pregnancy test object. Pregnancy tests now (optionally) require a pregnancy test to be purchased before hand.
- Pregnancy tests now longer give happy or sad buffs, they only show simple notifications. This works better for this mod since it is now possible to become pregnant accidentally. Sims shouldn't be necessarily be sad they didn't get pregnant from a one night stand, nor should they be necessarily happy if they did.
- Taking a pregnancy test will no longer jump a sim's pregnancy progress forward after taking a pregnancy test, like it does in the base game.
- Pregnancy tests can now be taken at any time, not just by sims who recently tried for a baby. They can also be taken by people who can't normally get pregnant by try for baby interactions.

### Quality of life improvements
- Notifications now appear when a sim runs out of condoms.
- Notifications also appear when two woohooing sims have a noticeable failure of their birth control methods. 

### Other Changes
- Box of condoms price, 100 > 75 


## v1.1.0 (June 24, 2020)

### Fixed bugs
- It is now no longer impossible to get pregnant after saving once.
- The pregnancy time setting can actually changes things now.
- Pregnant teens now receive the pregnancy moodlets and correctly physically show their pregnancy.
- Reproductive systems and dot information are now correctly load data when loading a game from the main menu.
- The dot cycle tracker app can now exit out of pregnancy mode.

## v1.0.0 (June 19, 2020)
 - Initial release