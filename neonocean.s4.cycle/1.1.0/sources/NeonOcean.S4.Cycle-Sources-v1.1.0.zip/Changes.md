## v1.0.1 (June 24, 2020)

### Fixed bugs
- It is now no longer impossible to get pregnant after saving once.
- The pregnancy time setting can actually changes things now.
- Pregnant teens now receive the pregnancy moodlets and correctly physically show their pregnancy.
- Reproductive systems and dot information are now correctly load data when loading a game from the main menu.
- The dot cycle tracker app can now exit out of pregnancy mode.

## v1.0.0 (June 19, 2020)
 - Initial release