FeminineFrameTraitID = 136878  # type: int
MasculineFrameTraitID = 136877  # type: int

FemaleBellyPositiveModifierKey = 16391756994022883177  # type: int
FemaleBellyNegativeModifierKey = 15575175292544645782  # type: int

MaleBellyPositiveModifierKey = 5705220627947342604  # type: int
MaleBellyNegativeModifierKey = 167019263877688587  # type: int

PregnancyNotShowingBuffID = 12560  # type: int
PregnancyFirstTrimesterBuffID = 12561  # type: int
PregnancySecondTrimesterBuffID = 12562  # type: int
PregnancyThirdTrimesterBuffID = 12563  # type: int
PregnancyInLaborBuffID = 75271  # type: int