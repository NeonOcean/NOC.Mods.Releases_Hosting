## v1.1.1 (July 2, 2020)

### Performance Improvements
- Improved load times in heavily modded games.

### Fixed bugs
- Changing whether or not a sim should use condoms will no longer cause minor loading errors.

### Other Improvements
- Added system to try to always remember which sim is which, even if another mod goes and changes their sim id.

## v1.1.0 (June 24, 2020)

### Fixed bugs
- It is now no longer impossible to get pregnant after saving once.
- The pregnancy time setting can actually changes things now.
- Pregnant teens now receive the pregnancy moodlets and correctly physically show their pregnancy.
- Reproductive systems and dot information are now correctly load data when loading a game from the main menu.
- The dot cycle tracker app can now exit out of pregnancy mode.

## v1.0.0 (June 19, 2020)
 - Initial release