# noinspection SpellCheckingInspection
DotAppIconKey = "00B2D882:00000000:9E820660FDFA9BFE"  # type: str