from __future__ import annotations

DotHandlerTypeIdentifier = "Dot"  # type: str