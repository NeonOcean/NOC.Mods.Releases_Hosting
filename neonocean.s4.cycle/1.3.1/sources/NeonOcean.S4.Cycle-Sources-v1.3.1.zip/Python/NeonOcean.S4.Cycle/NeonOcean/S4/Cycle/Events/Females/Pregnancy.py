from __future__ import annotations

from NeonOcean.S4.Cycle.Events import Base as EventsBase

class PregnancyStartedArguments(EventsBase.ReproductiveArguments):
	pass

class PregnancyEndedArguments(EventsBase.ReproductiveArguments):
	pass
