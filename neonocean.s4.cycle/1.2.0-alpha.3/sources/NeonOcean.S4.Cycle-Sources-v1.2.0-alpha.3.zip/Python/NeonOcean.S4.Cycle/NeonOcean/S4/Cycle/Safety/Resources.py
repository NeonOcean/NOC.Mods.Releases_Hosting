from __future__ import annotations

CondomWoohooSafetyMethodID = 14044826903803863935  # type: int
WithdrawWoohooSafetyMethodID = 13838596247621976478  # type: int
