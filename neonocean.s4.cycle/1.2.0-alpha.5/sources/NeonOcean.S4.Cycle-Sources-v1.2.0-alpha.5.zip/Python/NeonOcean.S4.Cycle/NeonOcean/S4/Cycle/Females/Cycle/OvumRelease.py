from __future__ import annotations

import typing

from NeonOcean.S4.Main.Tools import Savable, Exceptions

class OvumRelease(Savable.SavableExtension):
	def __init__(self):
		"""
		An object to keep track of the release of an individual ovum during a cycle.
		"""

		super().__init__()

		self.ReleaseMinute = 20160
		self.Released = False

		self._releaseGuarantors = list()  # type: typing.List[str]

		def releaseGuarantorsTypeVerifier (value: typing.List[str]) -> None:
			if not isinstance(value, list):
				raise Exceptions.IncorrectTypeException(value, "ReleaseGuarantors", (list, ))

			for guarantorIndex in range(len(value)):  # type: int
				guarantor = value[guarantorIndex]  # type: str

				if not isinstance(guarantor, str):
					raise Exceptions.IncorrectTypeException(value, "ReleaseGuarantors[%s]" % guarantorIndex, (str, ))

		self.RegisterSavableAttribute(Savable.StandardAttributeHandler("ReleaseMinute", "ReleaseMinute", self.ReleaseMinute, requiredAttribute = True))
		self.RegisterSavableAttribute(Savable.StandardAttributeHandler("Released", "Released", self.Released))

		self.RegisterSavableAttribute(Savable.StandardAttributeHandler("ReleaseGuarantors", "_releaseGuarantors", list(), typeVerifier = releaseGuarantorsTypeVerifier))

	@property
	def ReleaseMinute (self) -> float:
		"""
		The number of reproductive minutes into a cycle this object indicates there should be an ovum release.
		"""

		return self._releaseMinute

	@ReleaseMinute.setter
	def ReleaseMinute (self, value: float) -> None:
		"""
		The number of reproductive minutes into a cycle this object indicates there should be an ovum release.
		"""

		if not isinstance(value, (float, int)):
			raise Exceptions.IncorrectTypeException(value, "ReleaseMinute", (float, int))

		self._releaseMinute = value

	@property
	def Released (self) -> bool:
		"""
		Whether or not an ovum has already been released for this object.
		"""

		return self._released

	@Released.setter
	def Released (self, value: bool) -> None:
		if not isinstance(value, (bool, )):
			raise Exceptions.IncorrectTypeException(value, "ReleaseMinute", (bool, ))

		self._released = value

	def GuaranteeRelease (self, guarantorIdentifier: str) -> None:
		"""
		Indicate that the release of this particular ovum is guaranteed by a particular system. This doesn't mean that the ovum won't be stopped, just that this
		system should not try to stop it when it does.
		:param guarantorIdentifier: A unique identifier for the system guaranteeing the ovum's release. This identifier should also be used by the system too check if
		it previously guaranteed the ovum.
		:type guarantorIdentifier: str
		"""

		if not isinstance(guarantorIdentifier, str):
			raise Exceptions.IncorrectTypeException(guarantorIdentifier, "guarantorIdentifier", (str, ))

		if not guarantorIdentifier in self._releaseGuarantors:
			self._releaseGuarantors.append(guarantorIdentifier)

	def IsReleaseGuaranteed (self, guarantorIdentifier: str) -> bool:
		"""
		Get whether or not this system has been guaranteed by a system with this identifier.
		:param guarantorIdentifier: The unique identifier used by the system to guarantee the ovum's release.
		"""

		if not isinstance(guarantorIdentifier, str):
			raise Exceptions.IncorrectTypeException(guarantorIdentifier, "guarantorIdentifier", (str, ))

		return guarantorIdentifier in self._releaseGuarantors