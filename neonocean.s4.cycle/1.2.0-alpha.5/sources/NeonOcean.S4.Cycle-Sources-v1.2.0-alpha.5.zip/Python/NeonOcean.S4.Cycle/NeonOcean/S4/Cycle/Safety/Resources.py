from __future__ import annotations

CondomWoohooSafetyMethodID = 14044826903803863935  # type: int
WithdrawWoohooSafetyMethodID = 13838596247621976478  # type: int

BirthControlPillsObjectDefinitionID = 12374762101234918206  # type: int
BirthControlPillsCountStatisticID = 10149873938934991278  # type: int
