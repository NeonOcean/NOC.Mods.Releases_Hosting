NeonOceanID = 4719607191068539616  # type: int
OrderID = 10635246917734688906  # type: int
OrderModSettingsID = 16847123929679880475  # type: int
