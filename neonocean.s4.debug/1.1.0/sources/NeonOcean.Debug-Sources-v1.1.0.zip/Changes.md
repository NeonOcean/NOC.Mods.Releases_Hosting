## v1.1.0 (March 26, 2019)
 
- Log files now have a root element, as XML files are suppose to.
- Extra new line and indentation characters that are added to log files for readability are now commented out.
- Users will now be notified of errors that prevented logging new reports.
- In-game notifications will now appear telling you when an update is available.
- Interactions now exist that can direct you to web pages relevant to this mod, such as the documentation.
- Addition and removal of this mod are can now be facilitated through an installer or uninstaller. These currently are only usable on windows computers.
 
## v1.0.0 (July 26, 2018)
 - Initial release